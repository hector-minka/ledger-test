declare module "detect-node" {
  const isNode: boolean;
  export default isNode;
}
